package com.fhasix.raytax;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.Text;

public class RaytaxTextMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            TextRenderer textRenderer = client.textRenderer;

            Text text = Text.literal("HI RAYTAX IS HERE THE DEV OF FHASIX!");

            int screenWidth = drawContext.getScaledWindowWidth();
            int textWidth = textRenderer.getWidth(text);

            int x = screenWidth - textWidth - 10;
            int y = 10;

            drawContext.drawTextWithShadow(textRenderer, text, x, y, 0xFFFFFFFF);
        });
    }
}
