# FHASIX Raytax Text — Fabric 1.20.1

Client-side Fabric mod that displays:

**HI RAYTAX IS HERE THE DEV OF FHASIX!**

in the top-right corner of the Minecraft HUD.

The GitHub Actions workflow builds the remapped JAR and uploads it as an artifact.
